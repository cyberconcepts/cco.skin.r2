# Introduction

A responsive skin (or theme, if you prefer this term) 
based on bootstrap for the Zope-based web application platform 
[loops](http://www.wissen-statt-suchen.de) (in German).

For more information see
[www.cyberconcepts.org](https://www.cyberconcepts.org).
