from zope.publisher.interfaces.browser import IDefaultBrowserLayer


class CCO_R2(IDefaultBrowserLayer):
    """The CCO_R2 skin."""
